export VER_MAJOR=1
export VER_MINOR=0
export VER_PATCH=1
